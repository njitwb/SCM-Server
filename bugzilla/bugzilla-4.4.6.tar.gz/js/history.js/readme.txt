History.js (v1.7.1 - October 4 2011)
http://github.com/balupton/history.js
